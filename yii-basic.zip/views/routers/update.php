<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Routers */
?>
<div class="routers-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
