<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Routers */
?>
<div class="routers-view">
 
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'sapid',
            'hostname',
            'loopback',
            'mac_address',
        ],
    ]) ?>

</div>
