<?php

use slavkovrn\visualize\VisualizeWidget;
/* @var $this yii\web\View */
?>
<h1>geographics/index</h1>

<p>
    You may change the content of this page by modifying
    the file <code><?= __FILE__; ?></code>.
</p>

<?php echo VisualizeWidget::widget([
    'id' => 'graphic',      // Id of visualize widget should be unique at page
    'class' => 'graphic',   // Class to define stile
    'name' => 'Visualize',  // Name of visualize widget
    'style' => 'light',     // Style of widget (only 'dark' or 'light' option)
    'width' => 800,         // Width of widget in pixels
    'height' => 200,        // Height of widget in pixels
    'graphic' => [          // data of chart of structure defined
        'SIN' => [
                    number_format(0,5) => sin(0),
                    number_format(Pi()/4,5) => sin(Pi()/4),
                    number_format(Pi()/2,5) => sin(Pi()/2),
                    number_format(Pi()/2+Pi()/4,5) => sin(Pi()/2+Pi()/4),
                    number_format(Pi(),5) => sin(Pi()),
                    number_format(Pi()+Pi()/4,5) => sin(Pi()+Pi()/4),
                    number_format(Pi()+Pi()/2,5) => sin(Pi()+Pi()/2),
                    number_format(Pi()+Pi()/2+Pi()/4,5) => sin(Pi()+Pi()/2+Pi()/4),
                    number_format(2*Pi(),5) => sin(2*Pi()),
                 ],
        'COS' => [
                    number_format(0,5) => cos(0),
                    number_format(Pi()/4,5) => cos(Pi()/4),
                    number_format(Pi()/2,5) => cos(Pi()/2),
                    number_format(Pi()/2+Pi()/4,5) => cos(Pi()/2+Pi()/4),
                    number_format(Pi(),5) => cos(Pi()),
                    number_format(Pi()+Pi()/4,5) => cos(Pi()+Pi()/4),
                    number_format(Pi()+Pi()/2,5) => cos(Pi()+Pi()/2),
                    number_format(Pi()+Pi()/2+Pi()/4,5) => cos(Pi()+Pi()/2+Pi()/4),
                    number_format(2*Pi(),5) => cos(2*Pi()),
                 ],
    ]
]) ?>

<hr>
Test
