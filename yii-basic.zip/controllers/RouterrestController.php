<?php
namespace app\controllers;

use yii\rest\ActiveController;

class RouterrestController extends ActiveController
{
    public $modelClass = 'app\models\Routers';
    
    
    
    public function actionCreate()
    {
        $request = Yii::$app->request;
        $model = new Routers();  

        Yii::$app->response->format = Response::FORMAT_JSON;

        if($model->validate())
        {
            $model->save();
            return [
                'model' => $model,
            ];
        }
        else{
            return [
                    'status'=> "Error in saving Router data"
                ];
        }
    }
}