<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "routers".
 *
 * @property int $id
 * @property int $sapid
 * @property string $hostname
 * @property int $loopback
 * @property int $mac_address
 */
class Routers extends \yii\db\ActiveRecord 
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'routers';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['sapid', 'hostname', 'loopback', 'mac_address'], 'required'],
            [['sapid'], 'integer'],
            [['hostname','loopback'], 'unique'],
            [['loopback'],'ip', 'ipv6' => false],
            [['hostname'], 'string', 'max' => 14],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'sapid' => 'Sapid',
            'hostname' => 'Hostname',
            'loopback' => 'Loopback',
            'mac_address' => 'Mac Address',
        ];
    }
    
    
}
